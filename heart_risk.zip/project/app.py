from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load Machine Learning Model
with open("heart_disease_risk_2026_model.pkl", "rb") as file:
    model = pickle.load(file)

print("Heart Disease Risk Model Loaded Successfully")

# This MUST match model.feature_names_in_ exactly (order + names),
# otherwise the model will silently score the wrong columns.
FEATURE_ORDER = [
    "resting_bp_systolic",
    "resting_bp_diastolic",
    "cholesterol_total",
    "triglycerides",
    "fasting_blood_sugar",
    "hba1c",
    "resting_heart_rate",
    "max_heart_rate_achieved",
    "chest_pain_type",
    "exercise_induced_angina",
    "st_depression",
    "family_history",
    "alcohol_units_per_week",
    "exercise_minutes_per_week",
    "sleep_hours",
    "stress_score",
    "wearable_owner",
    "daily_steps",
    "diet_quality_score",
    "smoker_status_Current",
    "smoker_status_Former",
    "smoker_status_Never",
]


# Home Page
@app.route("/")
def home():
    return render_template("index.html")


# Login Page
@app.route("/login")
def login():
    return render_template("login.html")


# Register Page
@app.route("/register")
def register():
    return render_template("register.html")


# Prediction Page
@app.route("/predict")
def predict():
    return render_template("predict.html")


# Prediction Result
@app.route("/prediction", methods=["POST"])
def prediction():

    try:
        form = request.form

        # One-hot encode smoker_status from the single dropdown into the
        # three columns the model was trained on.
        smoker_choice = form.get("smoker_status", "Never")
        smoker_current = 1.0 if smoker_choice == "Current" else 0.0
        smoker_former = 1.0 if smoker_choice == "Former" else 0.0
        smoker_never = 1.0 if smoker_choice == "Never" else 0.0

        values = {
            "resting_bp_systolic": form.get("resting_bp_systolic"),
            "resting_bp_diastolic": form.get("resting_bp_diastolic"),
            "cholesterol_total": form.get("cholesterol_total"),
            "triglycerides": form.get("triglycerides"),
            "fasting_blood_sugar": form.get("fasting_blood_sugar"),
            "hba1c": form.get("hba1c"),
            "resting_heart_rate": form.get("resting_heart_rate"),
            "max_heart_rate_achieved": form.get("max_heart_rate_achieved"),
            "chest_pain_type": form.get("chest_pain_type"),
            "exercise_induced_angina": form.get("exercise_induced_angina"),
            "st_depression": form.get("st_depression"),
            "family_history": form.get("family_history"),
            "alcohol_units_per_week": form.get("alcohol_units_per_week"),
            "exercise_minutes_per_week": form.get("exercise_minutes_per_week"),
            "sleep_hours": form.get("sleep_hours"),
            "stress_score": form.get("stress_score"),
            "wearable_owner": form.get("wearable_owner"),
            "daily_steps": form.get("daily_steps"),
            "diet_quality_score": form.get("diet_quality_score"),
        }

        # Build the feature vector in the exact order the model expects
        features = []
        for name in FEATURE_ORDER:
            if name == "smoker_status_Current":
                features.append(smoker_current)
            elif name == "smoker_status_Former":
                features.append(smoker_former)
            elif name == "smoker_status_Never":
                features.append(smoker_never)
            else:
                features.append(float(values[name]))

        # Convert into numpy array
        input_data = np.array(features).reshape(1, -1)

        # Prediction
        result = model.predict(input_data)

        if result[0] == 1:
            output = "High Risk of Heart Disease"
        else:
            output = "Low Risk of Heart Disease"

        return render_template(
            "result.html",
            prediction_text=output
        )

    except Exception as e:
        return render_template(
            "result.html",
            prediction_text=f"Error: {e}"
        )


if __name__ == "__main__":
    app.run(debug=True)
